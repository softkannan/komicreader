﻿namespace SharpCompress
{
    public enum ArchiveType
    {
        Rar,
        Zip,
        Tar,
        SevenZip,
        GZip,
    }
}