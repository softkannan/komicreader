﻿namespace SharpCompress
{
    public enum CompressionType
    {
        None,
        GZip,
        BZip2,
        PPMd,
        Deflate,
        Rar,
        LZMA,
        Unknown,
    }
}