namespace SharpCompress.Compressor.Rar.decode
{
    internal enum FilterType
    {
        FILTER_NONE,
        FILTER_PPM,
        FILTER_E8,
        FILTER_E8E9,
        FILTER_UPCASETOLOW,
        FILTER_AUDIO,
        FILTER_RGB,
        FILTER_DELTA,
        FILTER_ITANIUM,
        FILTER_E8E9V2,
    }
}