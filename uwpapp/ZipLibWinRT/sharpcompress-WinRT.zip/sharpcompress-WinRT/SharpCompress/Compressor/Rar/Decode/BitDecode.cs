namespace SharpCompress.Compressor.Rar.decode
{
    internal class BitDecode : Decode
    {
        internal BitDecode()
            : base(new int[Compress.BC])
        {
        }
    }
}