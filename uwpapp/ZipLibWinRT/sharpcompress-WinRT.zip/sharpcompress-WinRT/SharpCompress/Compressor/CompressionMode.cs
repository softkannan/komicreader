﻿namespace SharpCompress.Compressor
{
    public enum CompressionMode
    {
        Compress = 0,
        Decompress = 1,
    }
}