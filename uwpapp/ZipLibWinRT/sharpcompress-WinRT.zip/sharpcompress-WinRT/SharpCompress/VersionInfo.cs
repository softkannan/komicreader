﻿using System.Reflection;
#if !PORTABLE
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
#endif

[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("Copyright © Adam Hathcock")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.8.2.0")]
[assembly: AssemblyFileVersion("0.8.2.0")]